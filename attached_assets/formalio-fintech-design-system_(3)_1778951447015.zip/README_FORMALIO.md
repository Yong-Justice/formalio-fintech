# Formalio — Fintech SaaS pour PME Africaines

## 🌍 Vue d'Ensemble

**Formalio** est un système d'exploitation fintech complet conçu pour les PME informelles et semi-formelles au Cameroun et en Afrique francophone. La plateforme aide les petites entreprises à devenir financièrement visibles, conformes fiscalement et éligibles au crédit.

### Mission
> Rendre chaque entreprise africaine visible, conforme et finançable.

---

##  Écosystème Complet

### 1. **Site Landing (Marketing)**
- Hero section avec mascot Mosika
- Présentation des fonctionnalités
- Tarifs (Gratuit, Croissance, Pro)
- Témoignages clients
- FAQ interactive
- Formulaire waitlist
- Footer complet

### 2. **Application Mobile (iOS/Android)**
**Flux d'Onboarding:**
- Splash screen animé
- Écrans de bienvenue
- Sélection de langue (FR, EN, Pidgin)
- Authentification par téléphone + OTP
- Configuration du business

**Fonctionnalités Core:**
- 📊 Dashboard financier en temps réel
- 💰 Suivi revenus/dépenses
- 📝 Saisie de transactions (manuel + vocal)
- 🏦 Sync Mobile Money (MTN MoMo, Orange Money)
- 📈 Score Mosika avec historique
- 📄 Rapports SYSCOHADA (PDF)
- 🔔 Notifications intelligentes
- 🤖 Assistant IA Mosika
- 📱 Mode hors ligne avec sync
- 🔐 Sécurité biométrique

### 3. **Dashboard Web (Desktop)**
- Navigation latérale
- Vue d'ensemble financière
- Graphiques interactifs (Recharts)
- Tableaux de transactions
- Export de données
- Gestion multi-comptes

### 4. **Portail Admin (Interne)**
- Analytics utilisateurs
- Revenus MRR/ARR
- Détection de fraude
- Support client
- Feature flags

### 5. **Portail Comptable**
- Gestion des clients
- Validation des rapports
- Workflows d'approbation
- Audit et conformité

### 6. **Portail Banque/MFI**
- Profils SME vérifiés
- Scoring de crédit
- Indicateurs de risque
- Pré-approbation de prêts

### 7. **Design System**
- Palette de couleurs (Formalio Green, Surface, Gold)
- Typographie (Inter)
- Composants UI (boutons, inputs, cards)
- États (empty, loading, error, offline)
- Shadows et espacements

---

## 🎨 Design System

### Couleurs Principales
```
Formalio Green: #059669 (primary)
Forest Green: #16a34a (secondary)
Gold: #f59e0b (accent)
Surface: #f8fafc à #0f172a (grays)
Danger: #ef4444
Info: #3b82f6
```

### Typographie
- **Font:** Inter (300-900)
- **Scale:** 12px → 48px
- **Hiérarchie:** Display, Heading, Body, Caption

### Composants
- Boutons (Primary, Secondary, Tertiary, Danger)
- Inputs (Default, With Icon, Error, Success)
- Cards (Default, Gradient, Muted)
- Toggle & Checkbox
- Toasts & Notifications
- Empty States
- Loading States
- Error States
- Offline States

---

## 🚀 Fonctionnalités Clés

### 1. **Score Mosika**
- Score de crédit 300-850
- 5 composantes pondérées:
  - Historique de paiement (35%)
  - Utilisation du crédit (25%)
  - Ancienneté des comptes (15%)
  - Diversité des crédits (15%)
  - Nouvelles demandes (10%)
- Offres de prêt pré-approuvées
- Conseils d'amélioration personnalisés

### 2. **Rapports SYSCOHADA**
- Bilan comptable conforme
- Compte de résultat
- Tableau de flux de trésorerie
- Déclaration de TVA
- Export PDF professionnel
- Génération en 1 clic

### 3. **Assistant IA Mosika**
- Catégorisation automatique de transactions
- Insights business personnalisés
- Alertes fiscales proactives
- Support conversationnel (FR/EN/Pidgin)
- Saisie vocale intelligente
- Recommandations actionnables

### 4. **Mobile Money Integration**
- MTN MoMo (Cameroun, Côte d'Ivoire, etc.)
- Orange Money (Afrique francophone)
- Wave (Sénégal, Côte d'Ivoire)
- Sync automatique des transactions
- Réconciliation intelligente

### 5. **Mode Hors Ligne**
- Fonctionnement sans connexion
- File d'attente de sync
- Indicateurs de statut
- Sync automatique au retour en ligne
- Préservation des données locales

---

## 🛠️ Stack Technique

### Frontend
- **React 19** + TypeScript
- **Vite** (build tool)
- **TailwindCSS 4** (styling)
- **Framer Motion** (animations)
- **Recharts** (data visualization)
- **Lucide React** (icons)

### Architecture
- Composants modulaires et réutilisables
- State management avec React hooks
- Responsive design (mobile-first)
- PWA-ready (offline support)
- Single-file build (vite-plugin-singlefile)

### Données (Demo)
- Données mockées dans `demoData.ts`
- Transactions, cashflow, scores
- Profils SME, clients, analytics
- Notifications et insights IA

---

## 📂 Structure du Projet

```
src/
├── assets/                    # Images (mascots)
│   ├── mascot-hero.png
│   ├── mascot-onboarding.png
│   └── mascot-secure.png
├── components/                # Composants UI
│   ├── Logo.tsx
│   ├── LandingPage.tsx
│   ├── MobileApp.tsx
│   ├── DesktopDashboard.tsx
│   ├── AdminDashboard.tsx
│   ├── AccountantPortal.tsx
│   ├── BankPortal.tsx
│   ├── DesignSystem.tsx
│   ├── SYSCOHADAReports.tsx   # Rapports OHADA
│   ├── MosikaScore.tsx        # Score de crédit
│   └── AIAssistant.tsx        # Chatbot IA
├── data/
│   └── demoData.ts            # Données mockées
├── types/
│   └── assets.d.ts            # Types TypeScript
├── utils/
│   └── cn.ts                  # Utility functions
├── App.tsx                    # Component principal
├── main.tsx                   # Entry point
└── index.css                  # Styles globaux
```

---

## 🎯 Cas d'Usage

### Utilisateurs Cibles
1. **Commerçants de marché** (Marché Madagascar, Marché Central)
2. **Propriétaires de boutique** (Quartiers, Villages)
3. **Opérateurs de transport** (Taxis, Bus, Motos)
4. **Restaurateurs** (Maquis, Restaurants, Snack-bars)
5. **Agriculteurs** (Coopératives, Exploitants)
6. **Prestataires de services** (Coiffeurs, Mécaniciens, etc.)

### Problèmes Résolus
- ❌ Pas de visibilité financière → ✅ Dashboard clair
- ❌ Comptabilité manuelle → ✅ Auto-catégorisation IA
- ❌ Pas d'historique de crédit → ✅ Score Mosika
- ❌ Difficulté d'accès au crédit → ✅ Prêts pré-approuvés
- ❌ Complexité fiscale → ✅ Rapports OHADA auto
- ❌ Connexion internet limitée → ✅ Mode hors ligne

---

## 🌐 Scalabilité Régionale

### Phase 1: Cameroun (2025)
- Douala, Yaoundé, Bafoussam
- MTN MoMo, Orange Money
- Conformité OHADA/CEMAC

### Phase 2: CEMAC (2026)
- Gabon, Congo, RCA, Tchad, Guinée Équatoriale
- BEAC regulations
- Multi-devises (XAF, XOF)

### Phase 3: Afrique Francophone (2027)
- Côte d'Ivoire, Sénégal, Mali, Burkina
- BCEAO regulations
- Wave integration

---

## 💰 Modèle Économique

### Plans
1. **Débutant** — Gratuit
   - 100 transactions/mois
   - Rapports basiques
   - Score Mosika

2. **Croissance** — 4,900 FCFA/mois
   - Transactions illimitées
   - Rapports OHADA
   - Sync Mobile Money
   - Insights IA

3. **Pro** — 12,900 FCFA/mois
   - Multi-utilisateurs
   - API access
   - Comptable dédié
   - Analyses avancées

### Revenue Streams
- Abonnements SaaS
- Commissions sur prêts (2-5%)
- API pour banques/MFI
- White-label pour institutions

---

## 🏆 Avantages Concurrentiels

1. **Premier système OHADA-native** pour informel
2. **IA contextualisée** pour l'Afrique (langues, usages)
3. **Offline-first** pour zones mal connectées
4. **Mobile Money deep integration**
5. **Mascot Mosika** — branding mémorable
6. **Design world-class** (niveau Stripe/Revolut)
7. **Écosystème complet** (SME + Banks + Accountants)

---

## 📊 Metrics Cibles (Année 1)

- **6,200+** utilisateurs inscrits
- **4,850** utilisateurs actifs quotidiens
- **18,500$** MRR
- **712** Score Mosika moyen
- **2.1%** Taux de défaut
- **5** pays couverts

---

## 🚀 Prochaines Étapes

### Court Terme (Q1 2025)
- [ ] Intégration backend (Supabase)
- [ ] Authentification réelle (OTP SMS)
- [ ] API Mobile Money (sandbox)
- [ ] Génération PDF réelle
- [ ] Tests utilisateurs (50 PME)

### Moyen Terme (Q2-Q3 2025)
- [ ] Applications natives (React Native)
- [ ] Machine Learning pour catégorisation
- [ ] Partenariats banques (BOA, Ecobank)
- [ ] Certification OHADA officielle
- [ ] Lancement public (beta)

### Long Terme (2026+)
- [ ] Expansion régionale (CEMAC)
- [ ] Marketplace de services financiers
- [ ] Credit scoring as a Service
- [ ] IPO / Exit strategy

---

## 👥 Équipe (Simulée)

- **CEO:** Vision produit & stratégie
- **CTO:** Architecture technique
- **CPO:** Design & UX
- **Head of Compliance:** Relations régulateurs
- **Lead Engineer:** Développement frontend
- **Data Scientist:** ML & scoring

---

## 📞 Contact

**Formalio Technologies**
- 📍 Douala, Cameroun
- 🌐 www.formalio.africa
- 📧 hello@formalio.africa
- 📱 +237 6XX XXX XXX

---

## 📄 Licence

© 2025 Formalio Technologies. Tous droits réservés.

*Business. Compliant. Growing.*
